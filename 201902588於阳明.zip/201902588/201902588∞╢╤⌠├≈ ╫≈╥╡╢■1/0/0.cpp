#include<stdio.h>
#include<iostream>
int main()
{
    int i, t;
    t = 1;
    i = 3;
    while (i <= 100)
    {
        t = t + i;
        i = i + 2;
    }
    printf("%d\n", t);
  	system ("pause");


}